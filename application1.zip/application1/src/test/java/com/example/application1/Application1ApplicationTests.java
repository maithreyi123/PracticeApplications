package com.example.application1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Application1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
